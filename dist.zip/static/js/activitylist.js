


var Edit_act_name = function (){
	console.log("dsafdsaddddddddddddddddd")
	if($('.input_edit_name').val() != ''){
		$("#node_edit_name_ok").css('display','block');
	}
}

export {Edit_act_name}